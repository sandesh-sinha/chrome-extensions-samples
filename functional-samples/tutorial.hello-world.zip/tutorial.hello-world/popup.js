console.log('This is a popup!');

console.log(chrome.enterpise);